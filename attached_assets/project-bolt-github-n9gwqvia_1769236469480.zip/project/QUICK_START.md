# Quick Start Guide - Get Real Data in 5 Minutes

## Step 1: Get Free API Keys (2 minutes)

### NewsAPI (Required)
1. Visit https://newsapi.org/register
2. Enter your email and name
3. Copy the API key shown
4. Keep it handy

### WeatherAPI (Required)
1. Visit https://www.weatherapi.com/signup.aspx
2. Sign up with email
3. Go to dashboard
4. Copy your API key

Both are completely free - no credit card needed!

## Step 2: Configure Your App (1 minute)

1. Create `.env` file:
```bash
cp .env.example .env
```

2. Open `.env` and add your keys:
```bash
NEWS_API_KEY=paste_your_newsapi_key_here
WEATHER_API_KEY=paste_your_weatherapi_key_here
```

3. Make sure DATABASE_URL is set (should be automatic with Supabase)

## Step 3: Start the App (2 minutes)

```bash
npm install
npm run dev
```

You should see:
```
Starting data scheduler...
Performing initial data fetch...
Fetched 50 news articles for Delhi
Fetched 50 news articles for Chandigarh
Updated weather alerts for Delhi
Updated fuel prices for Delhi
Data scheduler started successfully
serving on port 5000
```

## Step 4: Verify It Works

Visit http://localhost:5000 and you should see:

- Real news articles with images
- Live weather data
- Current fuel prices
- Traffic alerts (if rush hour)

## What Happens Now?

Your app will automatically:
- Fetch new news every 30 minutes
- Update weather every 15 minutes
- Check traffic every 10 minutes
- Update fuel prices daily
- Clean up old data hourly

## Troubleshooting

### No news showing?
- Check if NEWS_API_KEY is correct in .env
- Check server logs for errors
- Make sure you didn't exceed 100 requests/day

### No weather alerts?
- Check if WEATHER_API_KEY is correct
- Weather alerts only appear during severe conditions
- Check server logs for API errors

### Database errors?
- Make sure DATABASE_URL is set
- Run: `npm run db:push`
- Check Supabase dashboard

## Next Steps

- Deploy to production (Railway, Render, Vercel)
- Build iOS app: `npm run build:mobile && npm run ios`
- Customize update intervals in .env
- Add more cities in server/services files

## API Usage Monitor

Your current usage per day:
- News: ~48 requests (limit: 100)
- Weather: ~96 requests (limit: 1,370,000)

You're well within limits!

## Need Help?

- Full setup guide: `API_SETUP.md`
- Complete docs: `README.md`
- Migration details: `MIGRATION_COMPLETE.md`
- iOS guide: `IOS_SETUP_GUIDE.md`

Enjoy your real-time city data app!
