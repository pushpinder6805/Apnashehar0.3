# CityConnect - Real-Time City Information Hub

A modern, real-time city information platform that provides live updates on news, weather, traffic, fuel prices, and local offers for Delhi and Chandigarh.

## Features

- **Live News**: Real-time news from NewsAPI.org with images
- **Weather Alerts**: Live weather updates and severe weather warnings
- **Traffic Updates**: Rush hour alerts and traffic congestion notifications
- **Fuel Prices**: Daily updated fuel prices (Petrol, Diesel, CNG)
- **Local Offers**: Community-driven deals and discounts
- **Real-time Updates**: Auto-refreshing data every 15-30 minutes
- **5-Day History**: Access to last 5 days of news and data
- **Mobile Ready**: Capacitor-powered iOS app support

## Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS, Framer Motion
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM (Supabase)
- **Real-time Data**: Custom scheduler with public APIs
- **Mobile**: Capacitor for iOS deployment

## Getting Started

### Prerequisites

- Node.js 18+
- PostgreSQL database (Supabase recommended)
- Free API keys (see API_SETUP.md)

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up your environment:
   ```bash
   cp .env.example .env
   ```

4. Add your API keys to `.env`:
   - Get News API key from https://newsapi.org/register
   - Get Weather API key from https://www.weatherapi.com/signup.aspx
   - See API_SETUP.md for detailed instructions

5. Run database migrations:
   ```bash
   npm run db:push
   ```

6. Start the development server:
   ```bash
   npm run dev
   ```

7. Visit http://localhost:5000

## API Keys Setup

All required APIs have generous free tiers:

1. **NewsAPI.org** (Required)
   - Free: 100 requests/day
   - Perfect for 2 cities with 30-min updates

2. **WeatherAPI.com** (Required)
   - Free: 1 million calls/month
   - Includes weather alerts

See `API_SETUP.md` for complete setup instructions.

## Data Sources

### News
- Source: NewsAPI.org
- Updates: Every 30 minutes
- Coverage: Real-time news for Delhi & Chandigarh
- Retention: Last 5 days

### Weather
- Source: WeatherAPI.com
- Updates: Every 15 minutes
- Features: Live weather, alerts, forecasts

### Fuel Prices
- Source: Public fuel price databases
- Updates: Daily at midnight
- Retention: Last 30 days

### Traffic Alerts
- Source: Smart rush-hour detection
- Updates: Every 10 minutes
- Auto-deactivates: After 2 hours

### Offers
- Source: Community-submitted
- Platform: User-generated content

## Deployment

### Web Deployment

```bash
npm run build
npm start
```

Deploy to any Node.js hosting platform:
- Railway
- Render
- Vercel
- Heroku
- DigitalOcean

### iOS Deployment

```bash
npm run build:mobile
npm run ios
```

See `IOS_SETUP_GUIDE.md` for complete iOS setup instructions.

## Project Structure

```
project/
├── client/               # React frontend
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── pages/       # Page components
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utilities and context
│   └── index.html
├── server/              # Express backend
│   ├── services/        # External API integrations
│   │   ├── news-service.ts
│   │   ├── weather-service.ts
│   │   ├── fuel-service.ts
│   │   ├── traffic-service.ts
│   │   └── scheduler.ts
│   ├── routes.ts        # API routes
│   ├── storage.ts       # Database layer
│   └── db.ts           # Database connection
├── shared/              # Shared types and schemas
│   ├── schema.ts        # Database schema
│   └── routes.ts        # API contract
└── migrations/          # Database migrations
```

## API Endpoints

- `GET /api/cities` - List of supported cities
- `GET /api/news?city={city}` - Get news for a city
- `GET /api/alerts?city={city}&category={category}` - Get alerts
- `POST /api/alerts` - Create new alert
- `GET /api/fuel?city={city}` - Get fuel prices
- `GET /api/offers?city={city}` - Get local offers

## Environment Variables

```bash
# Database
DATABASE_URL=postgresql://...

# Required APIs
NEWS_API_KEY=your_news_api_key
WEATHER_API_KEY=your_weather_api_key

# Optional
OPENWEATHER_API_KEY=alternative_weather_api
GOOGLE_MAPS_API_KEY=for_enhanced_traffic

# Update Intervals (minutes)
NEWS_UPDATE_INTERVAL=30
WEATHER_UPDATE_INTERVAL=15
FUEL_UPDATE_INTERVAL=1440
ALERTS_CLEANUP_INTERVAL=60
```

## Features Roadmap

- [ ] Google Maps Traffic API integration
- [ ] Push notifications for alerts
- [ ] Android app support
- [ ] More cities (Mumbai, Bangalore)
- [ ] User accounts and preferences
- [ ] Favorite offers and saved searches
- [ ] Public transport schedules
- [ ] Air quality index (AQI)

## Data Privacy

- No user tracking
- All data fetched from public sources
- Community alerts are anonymous
- No personal information collected

## Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - feel free to use this project for any purpose.

## Support

For issues or questions:
- Check `API_SETUP.md` for API setup help
- Check `IOS_SETUP_GUIDE.md` for iOS deployment
- See `QUICK_START_IOS.md` for quick mobile setup

## Credits

Data sources:
- NewsAPI.org for news
- WeatherAPI.com for weather
- Public fuel price databases
- Community contributions

Built with love for the cities of India.
