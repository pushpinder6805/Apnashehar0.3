# Quick Start - iOS in 5 Minutes

## 1. Install Dependencies
```bash
npm install
```

## 2. Setup Environment
Create `.env` file:
```bash
VITE_API_URL=https://your-replit-url.repl.co
```

Get your Replit URL:
- It's shown at the top of your Replit workspace
- Format: `https://[project-name].[username].repl.co`

## 3. Build & Initialize iOS
```bash
npm run build
npx cap add ios
```

## 4. Update Capacitor Config
Edit `capacitor.config.ts` line 8:
```typescript
url: 'https://your-actual-replit-url.repl.co',
```

## 5. Sync and Open
```bash
npm run build:mobile
npm run ios
```

## 6. Run in Xcode
1. Select a simulator
2. Click the Play button
3. Wait for build to complete

---

## Still White Screen?

### Check Backend is Running
```bash
curl https://your-replit-url.repl.co/api/cities
```
Should return: `["Chandigarh","Delhi"]`

### Check iOS Console
- In Simulator, open Safari
- Develop > Simulator > [Your App]
- Look for red errors in Console

### Common Fixes
1. Make sure Replit is running (keep it awake)
2. Verify URL in `.env` has no trailing slash
3. Rebuild: `npm run build:mobile`

---

That's it! Your app should now work on iOS.
