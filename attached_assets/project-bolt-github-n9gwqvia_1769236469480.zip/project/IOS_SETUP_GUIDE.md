# iOS Setup Guide for CityConnect

## Overview
This guide will help you convert your CityConnect web app into a native iOS application using Capacitor.

---

## Prerequisites

1. **macOS** - iOS development requires macOS
2. **Xcode 15+** - Download from Mac App Store
3. **CocoaPods** - Install with: `sudo gem install cocoapods`
4. **Node.js 18+** - Already installed if you're running the app

---

## Step 1: Install Dependencies

```bash
npm install
```

This will install Capacitor and iOS platform dependencies.

---

## Step 2: Configure Backend URL

Create a `.env` file in the project root:

```bash
# Replace with your actual Replit URL or deployed backend
VITE_API_URL=https://your-replit-url.repl.co
```

**IMPORTANT**: You need to deploy your backend somewhere accessible. Options:
- Keep your Replit running and use the Replit URL
- Deploy to Railway, Render, or Heroku
- Use a VPS with a public IP

---

## Step 3: Initialize iOS Platform

```bash
# Build the web app
npm run build

# Initialize Capacitor iOS
npx cap add ios
```

This creates an `ios/` folder with your iOS project.

---

## Step 4: Update capacitor.config.ts

Edit `capacitor.config.ts` and set your backend URL:

```typescript
server: {
  url: 'https://your-actual-backend-url.com',
  cleartext: true
}
```

---

## Step 5: Build and Sync

```bash
# Build the web app and sync to iOS
npm run build:mobile
```

---

## Step 6: Open in Xcode

```bash
# Open the iOS project in Xcode
npm run ios
```

This will launch Xcode with your iOS project.

---

## Step 7: Configure iOS App in Xcode

1. **Select your Team**:
   - Click on the project name in the left sidebar
   - Select the "Signing & Capabilities" tab
   - Choose your Apple Developer Team

2. **Change Bundle Identifier** (if needed):
   - Update from `com.cityconnect.app` to your own identifier
   - Format: `com.yourcompany.appname`

3. **Set Deployment Target**:
   - Set to iOS 13.0 or higher

---

## Step 8: Test on Simulator

1. Select a simulator from the device dropdown (top of Xcode)
2. Click the "Play" button or press `Cmd + R`
3. The app will build and launch in the simulator

---

## Step 9: Test on Real Device

1. Connect your iPhone via USB
2. Select your iPhone from the device dropdown
3. Click "Play" to build and install on your device

---

## Troubleshooting White Screen

If you see a white screen:

### 1. Check Network Requests
Open Safari on iOS (or simulator):
- Settings > Safari > Advanced > Web Inspector
- Connect to simulator/device
- Check Console for errors

### 2. Verify Backend URL
```bash
# Test if backend is accessible
curl https://your-backend-url.com/api/cities
```

Should return: `["Chandigarh","Delhi"]`

### 3. Check CORS
Make sure your backend allows requests from the iOS app. Add this to your Express server:

```javascript
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});
```

### 4. Enable HTTP (for development)
In Xcode, edit `Info.plist` and add:

```xml
<key>NSAppTransportSecurity</key>
<dict>
  <key>NSAllowsArbitraryLoads</key>
  <true/>
</dict>
```

### 5. Clear Cache
```bash
# Clean and rebuild
rm -rf ios/App/build
npm run build:mobile
```

---

## Alternative: Quick Test with Dev Server

For quick testing without deploying backend:

1. Find your Mac's local IP:
   ```bash
   ifconfig | grep "inet " | grep -v 127.0.0.1
   ```

2. Start dev server:
   ```bash
   npm run dev
   ```

3. Update `.env`:
   ```bash
   VITE_API_URL=http://YOUR_MAC_IP:5000
   ```

4. Update `capacitor.config.ts`:
   ```typescript
   server: {
     url: 'http://YOUR_MAC_IP:5000',
     cleartext: true
   }
   ```

5. Rebuild and sync:
   ```bash
   npm run build:mobile
   ```

**Note**: Your iPhone and Mac must be on the same WiFi network.

---

## Production Deployment

### 1. Deploy Backend
Deploy your backend to a production service:
- Railway.app (recommended, free tier)
- Render.com
- Heroku
- AWS/GCP/Azure

### 2. Update Environment
Set production URLs in `.env`:
```bash
VITE_API_URL=https://your-production-api.com
```

### 3. Build for Production
```bash
NODE_ENV=production npm run build:mobile
```

### 4. App Store Submission
1. Create an App Store Connect account
2. Create a new app listing
3. Archive your app in Xcode
4. Upload to App Store Connect
5. Submit for review

---

## Common Issues

### White Screen
- Check backend URL is correct and accessible
- Check browser console for errors
- Verify CORS is configured

### Build Errors
- Make sure Xcode is updated
- Run `pod install` in the `ios/App` folder
- Clean build folder in Xcode: Product > Clean Build Folder

### Network Errors
- Backend must be accessible from the device
- Check firewall settings
- Verify API endpoints return data

---

## File Structure

```
project/
├── capacitor.config.ts          # Capacitor configuration
├── ios/                          # iOS native project
│   └── App/                      # Xcode project
├── client/                       # Web app source
│   └── src/
│       └── lib/
│           └── api-config.ts    # API URL configuration
└── dist/public/                  # Built web app (synced to iOS)
```

---

## Support

If you're still seeing a white screen:
1. Check the Safari Web Inspector console
2. Verify the backend is accessible: `curl https://your-backend/api/cities`
3. Make sure `.env` has the correct `VITE_API_URL`
4. Rebuild: `npm run build:mobile`

---

## Next Steps

- Test all features on iOS
- Optimize performance
- Add iOS-specific features (push notifications, etc.)
- Submit to App Store
