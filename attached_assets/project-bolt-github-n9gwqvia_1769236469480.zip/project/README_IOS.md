# CityConnect - iOS App

Your web app is now configured for iOS! This was a web application that needed modifications to work on mobile devices.

## What Changed

I've made the following changes to fix the white screen issue and enable iOS deployment:

### 1. Added API Configuration
- Created `client/src/lib/api-config.ts` - handles API URL configuration for mobile
- Updated all API calls in `use-city-data.ts` to use the new configuration
- Now the app knows where to find your backend server

### 2. Added Capacitor (iOS Framework)
- Added Capacitor dependencies to package.json
- Created `capacitor.config.ts` - configuration for iOS app
- Added build scripts for mobile deployment

### 3. Created Setup Guides
- `QUICK_START_IOS.md` - Get started in 5 minutes
- `IOS_SETUP_GUIDE.md` - Detailed instructions and troubleshooting
- `check-ios-setup.js` - Diagnostic script to verify setup

## Why You Got a White Screen

The white screen happened because:

1. **Missing Backend URL**: The app was trying to call `/api/*` which doesn't exist on iOS
2. **Local Server Issue**: `localhost:5000` only works on the same machine, not on iOS devices
3. **No Mobile Configuration**: The web app wasn't set up for mobile deployment

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Create .env file with your backend URL
echo "VITE_API_URL=https://your-replit-url.repl.co" > .env

# 3. Build the app
npm run build

# 4. Add iOS platform
npx cap add ios

# 5. Update capacitor.config.ts with your backend URL

# 6. Sync and open in Xcode
npm run build:mobile
npm run ios
```

## Important Notes

### Backend Server
Your backend MUST be accessible from the iOS device:
- If using Replit: Keep your Replit running and use its public URL
- If using local dev: Use your Mac's local IP (e.g., `http://192.168.1.5:5000`)
- Production: Deploy to Railway, Render, or similar service

### Environment Setup
Create a `.env` file:
```bash
VITE_API_URL=https://your-backend-url.com
```

Update `capacitor.config.ts`:
```typescript
server: {
  url: 'https://your-backend-url.com',
  cleartext: true
}
```

## Diagnostic Tool

Run the setup checker:
```bash
node check-ios-setup.js
```

This will tell you exactly what's missing or misconfigured.

## Troubleshooting

### Still seeing white screen?

1. **Check Safari Console**:
   - Open simulator
   - Safari > Develop > Simulator > Your App
   - Look for red errors

2. **Verify Backend**:
   ```bash
   curl https://your-backend/api/cities
   ```
   Should return: `["Chandigarh","Delhi"]`

3. **Rebuild**:
   ```bash
   npm run build:mobile
   ```

4. **Check CORS**: Make sure your Express server allows cross-origin requests

### Build errors in Xcode?

- Update Xcode to latest version
- Run `pod install` in `ios/App/` folder
- Clean build: Product > Clean Build Folder in Xcode

## Next Steps

1. Test all features in simulator
2. Test on real iPhone
3. Add app icon and splash screen
4. Submit to App Store

## File Structure

```
project/
├── capacitor.config.ts              # iOS configuration
├── .env                              # Backend URL
├── ios/                              # iOS native project
│   └── App/                          # Xcode project
├── client/src/
│   └── lib/
│       └── api-config.ts            # API URL handler
├── QUICK_START_IOS.md               # Quick guide
├── IOS_SETUP_GUIDE.md               # Detailed guide
└── check-ios-setup.js               # Diagnostic tool
```

## Get Help

If you're stuck:
1. Run `node check-ios-setup.js`
2. Read `QUICK_START_IOS.md` for common issues
3. Check `IOS_SETUP_GUIDE.md` for detailed troubleshooting

Your app should now work perfectly on iOS!
