import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cityconnect.app',
  appName: 'CityConnect',
  webDir: 'dist/public',
  server: {
    // For mobile builds, set CAPACITOR_SERVER_URL to your deployed backend
    // For web, leave undefined to use relative paths
    url: process.env.CAPACITOR_SERVER_URL,
    cleartext: true // Allow HTTP in development
  },
  ios: {
    contentInset: 'automatic',
    scrollEnabled: true
  }
};

export default config;
