import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Fuel Prices (Daily updates)
export const fuelPrices = pgTable("fuel_prices", {
  id: serial("id").primaryKey(),
  city: text("city").notNull(), // 'Delhi' or 'Chandigarh'
  type: text("type").notNull(), // 'Petrol', 'Diesel', 'CNG'
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("INR"),
  date: timestamp("date").defaultNow(), // Date of the price
});

// Alerts (Traffic & Power Cuts)
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  city: text("city").notNull(),
  category: text("category").notNull(), // 'traffic', 'power', 'weather'
  title: text("title").notNull(),
  message: text("message").notNull(),
  severity: text("severity").notNull(), // 'low', 'medium', 'high', 'critical'
  area: text("area").notNull(), // e.g., 'Sector 17', 'Connaught Place'
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Local News
export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  city: text("city").notNull(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  source: text("source").notNull(),
  url: text("url").unique(), // Link to full article (unique to prevent duplicates)
  imageUrl: text("image_url"),
  publishedAt: timestamp("published_at").defaultNow(),
});

// Local Offers/Deals
export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  city: text("city").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  code: text("code"), // Coupon code if any
  expiresAt: timestamp("expires_at"),
  businessName: text("business_name").notNull(),
  category: text("category").notNull(), // 'food', 'retail', 'services'
});

// === SCHEMAS ===

export const insertFuelPriceSchema = createInsertSchema(fuelPrices).omit({ id: true, date: true });
export const insertAlertSchema = createInsertSchema(alerts).omit({ id: true, createdAt: true });
export const insertNewsSchema = createInsertSchema(news).omit({ id: true, publishedAt: true });
export const insertOfferSchema = createInsertSchema(offers).omit({ id: true });

// === EXPLICIT TYPES ===

export type FuelPrice = typeof fuelPrices.$inferSelect;
export type InsertFuelPrice = z.infer<typeof insertFuelPriceSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type NewsItem = typeof news.$inferSelect;
export type InsertNewsItem = z.infer<typeof insertNewsSchema>;

export type Offer = typeof offers.$inferSelect;
export type InsertOffer = z.infer<typeof insertOfferSchema>;
