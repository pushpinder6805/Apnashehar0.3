import { z } from 'zod';
import { 
  insertFuelPriceSchema, 
  insertAlertSchema, 
  insertNewsSchema, 
  insertOfferSchema,
  fuelPrices,
  alerts,
  news,
  offers 
} from './schema';

// === SHARED ERROR SCHEMAS ===
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// === API CONTRACT ===
export const api = {
  // === FUEL PRICES ===
  fuel: {
    list: {
      method: 'GET' as const,
      path: '/api/fuel',
      input: z.object({
        city: z.string().optional(), // Filter by city
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof fuelPrices.$inferSelect>()),
      },
    },
  },

  // === ALERTS (Traffic, Power, etc) ===
  alerts: {
    list: {
      method: 'GET' as const,
      path: '/api/alerts',
      input: z.object({
        city: z.string().optional(),
        category: z.string().optional(),
        active: z.boolean().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof alerts.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/alerts',
      input: insertAlertSchema,
      responses: {
        201: z.custom<typeof alerts.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },

  // === NEWS ===
  news: {
    list: {
      method: 'GET' as const,
      path: '/api/news',
      input: z.object({
        city: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof news.$inferSelect>()),
      },
    },
  },

  // === OFFERS ===
  offers: {
    list: {
      method: 'GET' as const,
      path: '/api/offers',
      input: z.object({
        city: z.string().optional(),
        category: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof offers.$inferSelect>()),
      },
    },
  },
  
  // === CITIES ===
  cities: {
    list: {
      method: 'GET' as const,
      path: '/api/cities',
      responses: {
        200: z.array(z.string()), // Returns ['Delhi', 'Chandigarh']
      },
    }
  }
};

// === URL HELPER ===
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// === TYPE HELPERS ===
export type FuelPriceResponse = z.infer<typeof api.fuel.list.responses[200]>[number];
export type AlertResponse = z.infer<typeof api.alerts.list.responses[200]>[number];
export type NewsResponse = z.infer<typeof api.news.list.responses[200]>[number];
export type OfferResponse = z.infer<typeof api.offers.list.responses[200]>[number];
