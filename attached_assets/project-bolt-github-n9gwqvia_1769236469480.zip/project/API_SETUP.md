# Public API Setup Guide

This app now uses real public APIs instead of hardcoded data. Follow these steps to get your free API keys.

## Required API Keys (All FREE)

### 1. News API (Required for news)
- Visit: https://newsapi.org/register
- Sign up for a free account
- Get your API key from the dashboard
- Free tier: 100 requests/day
- Add to `.env`: `NEWS_API_KEY=your_key_here`

### 2. Weather API (Required for weather alerts)
Choose ONE of these options:

#### Option A: WeatherAPI.com (Recommended)
- Visit: https://www.weatherapi.com/signup.aspx
- Sign up for a free account
- Get your API key
- Free tier: 1M calls/month
- Add to `.env`: `WEATHER_API_KEY=your_key_here`

#### Option B: OpenWeatherMap
- Visit: https://openweathermap.org/api
- Sign up and get API key
- Free tier: 1000 calls/day
- Add to `.env`: `OPENWEATHER_API_KEY=your_key_here`

## Optional APIs (for enhanced features)

### Google Maps Traffic API
- Visit: https://console.cloud.google.com/
- Enable Maps JavaScript API and Traffic Layer
- Get API key
- Add to `.env`: `GOOGLE_MAPS_API_KEY=your_key_here`

## Setup Steps

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Add your API keys to `.env` file

3. Make sure your Supabase database is running

4. Start the server:
   ```bash
   npm run dev
   ```

5. The app will automatically:
   - Fetch news every 30 minutes
   - Update weather every 15 minutes
   - Update fuel prices daily
   - Create traffic alerts during rush hours
   - Clean up old data automatically

## Data Sources

The app fetches data from:

- **News**: NewsAPI.org - Real-time news for Delhi & Chandigarh
- **Weather**: WeatherAPI.com - Live weather and alerts
- **Fuel Prices**: Scraped from public sources (updates daily)
- **Traffic**: Smart rush-hour detection + future Google Maps integration
- **Offers**: Community-submitted deals stored in database

## Update Intervals

You can customize update frequencies in `.env`:

```bash
NEWS_UPDATE_INTERVAL=30        # Minutes
WEATHER_UPDATE_INTERVAL=15     # Minutes
FUEL_UPDATE_INTERVAL=1440      # Minutes (24 hours)
ALERTS_CLEANUP_INTERVAL=60     # Minutes
```

## Data Retention

- News articles: Last 5 days
- Fuel prices: Last 30 days
- Weather alerts: Auto-deactivate after conditions clear
- Traffic alerts: Auto-deactivate after 2 hours
- User-submitted alerts: Keep indefinitely

## No More Replit Dependencies

All Replit URLs have been removed. The app now:
- Uses relative paths for web deployment
- Fetches real data from public APIs
- Stores everything in your Supabase database
- Updates automatically in real-time
- Works on any hosting platform

## Free API Limits

| API | Free Tier | Limit |
|-----|-----------|-------|
| NewsAPI | Yes | 100 requests/day |
| WeatherAPI | Yes | 1M calls/month |
| OpenWeatherMap | Yes | 1000 calls/day |
| Google Maps | Free trial | $200 credit |

All limits are more than sufficient for this app's needs.
