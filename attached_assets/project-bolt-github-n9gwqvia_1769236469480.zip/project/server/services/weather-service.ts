import { storage } from "../storage";

interface WeatherAPIResponse {
  current: {
    temp_c: number;
    condition: {
      text: string;
      code: number;
    };
    wind_kph: number;
    humidity: number;
  };
  alerts?: {
    alert: Array<{
      headline: string;
      severity: string;
      event: string;
      desc: string;
    }>;
  };
}

export class WeatherService {
  private readonly apiKey = process.env.WEATHER_API_KEY || process.env.OPENWEATHER_API_KEY;
  private readonly baseUrl = process.env.WEATHER_API_KEY
    ? "https://api.weatherapi.com/v1"
    : "https://api.openweathermap.org/data/2.5";

  private readonly cityCoords: Record<string, { lat: number; lon: number }> = {
    Delhi: { lat: 28.6139, lon: 77.2090 },
    Chandigarh: { lat: 30.7333, lon: 76.7794 },
  };

  async fetchAndStoreWeatherAlerts() {
    if (!this.apiKey) {
      console.log("Weather API key not set, skipping weather alerts");
      return;
    }

    for (const [city, coords] of Object.entries(this.cityCoords)) {
      try {
        // Using WeatherAPI.com (free tier includes alerts)
        const response = await fetch(
          `${this.baseUrl}/current.json?key=${this.apiKey}&q=${coords.lat},${coords.lon}&alerts=yes`
        );

        if (!response.ok) {
          console.error(`Failed to fetch weather for ${city}`);
          continue;
        }

        const data: WeatherAPIResponse = await response.json();

        // Create weather-based alerts
        if (data.alerts?.alert) {
          for (const alert of data.alerts.alert) {
            await storage.createAlert({
              city,
              category: "weather",
              title: alert.headline,
              message: alert.desc,
              severity: this.mapSeverity(alert.severity),
              area: "All Districts",
              active: true,
            });
          }
        }

        // Create alerts for extreme conditions
        if (data.current.temp_c > 40) {
          await storage.createAlert({
            city,
            category: "weather",
            title: "Extreme Heat Alert",
            message: `Temperature is ${data.current.temp_c}°C. Stay hydrated and avoid outdoor activities.`,
            severity: "high",
            area: "All Districts",
            active: true,
          });
        }

        if (data.current.wind_kph > 50) {
          await storage.createAlert({
            city,
            category: "weather",
            title: "High Wind Warning",
            message: `Wind speed is ${data.current.wind_kph} km/h. Secure loose objects and drive carefully.`,
            severity: "medium",
            area: "All Districts",
            active: true,
          });
        }

        console.log(`Updated weather alerts for ${city}`);
      } catch (error) {
        console.error(`Error fetching weather for ${city}:`, error);
      }
    }
  }

  private mapSeverity(severity: string): "low" | "medium" | "high" | "critical" {
    const s = severity.toLowerCase();
    if (s.includes("extreme") || s.includes("severe")) return "critical";
    if (s.includes("moderate")) return "medium";
    if (s.includes("minor")) return "low";
    return "medium";
  }
}

export const weatherService = new WeatherService();
