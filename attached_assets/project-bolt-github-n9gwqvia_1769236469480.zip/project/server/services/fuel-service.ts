import { storage } from "../storage";
import { fuelPriceScraper } from "./fuel-scraper";

export class FuelService {
  async fetchAndStoreFuelPrices() {
    const cities = ["Delhi", "Chandigarh"];

    for (const city of cities) {
      try {
        const prices = await fuelPriceScraper.fetchFuelPricesForCity(city);
        if (!prices) continue;

        // Store each fuel type
        await storage.createFuelPrice({
          city,
          type: "Petrol",
          price: prices.petrol.toString(),
        });

        await storage.createFuelPrice({
          city,
          type: "Diesel",
          price: prices.diesel.toString(),
        });

        await storage.createFuelPrice({
          city,
          type: "CNG",
          price: prices.cng.toString(),
        });

        console.log(`Updated fuel prices for ${city}: Petrol ₹${prices.petrol}, Diesel ₹${prices.diesel}, CNG ₹${prices.cng}`);
      } catch (error) {
        console.error(`Error updating fuel prices for ${city}:`, error);
      }
    }
  }

  async cleanupOldPrices() {
    try {
      await storage.deleteOldFuelPrices(30);
      console.log("Cleaned up old fuel prices");
    } catch (error) {
      console.error("Error cleaning up fuel prices:", error);
    }
  }
}

export const fuelService = new FuelService();
