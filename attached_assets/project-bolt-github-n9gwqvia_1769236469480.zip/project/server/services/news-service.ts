import { storage } from "../storage";

interface NewsAPIResponse {
  status: string;
  totalResults: number;
  articles: Array<{
    source: { name: string };
    title: string;
    description: string;
    url: string;
    urlToImage?: string;
    publishedAt: string;
  }>;
}

export class NewsService {
  private readonly apiKey = process.env.NEWS_API_KEY;
  private readonly baseUrl = "https://newsapi.org/v2";

  async fetchAndStoreNews() {
    if (!this.apiKey) {
      console.log("NEWS_API_KEY not set, skipping news fetch");
      return;
    }

    const cities = ["Delhi", "Chandigarh"];

    for (const city of cities) {
      try {
        const response = await fetch(
          `${this.baseUrl}/everything?q=${encodeURIComponent(city)}&language=en&sortBy=publishedAt&pageSize=50&apiKey=${this.apiKey}`
        );

        if (!response.ok) {
          console.error(`Failed to fetch news for ${city}: ${response.statusText}`);
          continue;
        }

        const data: NewsAPIResponse = await response.json();

        // Store in database
        for (const article of data.articles.slice(0, 20)) {
          try {
            await storage.createNews({
              city,
              title: article.title,
              summary: article.description || article.title.substring(0, 200),
              source: article.source.name,
              url: article.url,
              imageUrl: article.urlToImage,
            });
          } catch (err) {
            // Skip duplicates
            console.log(`Skipping duplicate news: ${article.title.substring(0, 30)}...`);
          }
        }

        console.log(`Fetched ${data.articles.length} news articles for ${city}`);
      } catch (error) {
        console.error(`Error fetching news for ${city}:`, error);
      }
    }
  }

  async cleanupOldNews() {
    // Remove news older than 5 days
    try {
      await storage.deleteOldNews(5);
      console.log("Cleaned up old news articles");
    } catch (error) {
      console.error("Error cleaning up news:", error);
    }
  }
}

export const newsService = new NewsService();
