import { storage } from "../storage";

// Traffic data can be fetched from various sources
// Google Maps Traffic API, TomTom, HERE Maps, etc.
export class TrafficService {
  private readonly delhiAreas = [
    "ITO Junction", "Connaught Place", "Kashmere Gate", "AIIMS",
    "Dwarka", "Rohini", "Lajpat Nagar", "Saket", "Nehru Place"
  ];

  private readonly chandigarhAreas = [
    "Sector 17", "Tribune Chowk", "Sector 35", "Panjab University",
    "Sector 22", "Industrial Area", "Mohali Phase 9"
  ];

  async checkAndCreateTrafficAlerts() {
    // In production, integrate with Google Maps Traffic API or similar
    // For now, creating sample alerts based on time patterns

    const currentHour = new Date().getHours();
    const isRushHour = (currentHour >= 8 && currentHour <= 10) ||
                       (currentHour >= 17 && currentHour <= 20);

    if (isRushHour) {
      // Create traffic alerts for rush hours
      await this.createRushHourAlerts();
    }

    console.log("Traffic alerts updated");
  }

  private async createRushHourAlerts() {
    // Delhi rush hour alerts
    const delhiArea = this.delhiAreas[Math.floor(Math.random() * this.delhiAreas.length)];
    await storage.createAlert({
      city: "Delhi",
      category: "traffic",
      title: `Heavy Traffic at ${delhiArea}`,
      message: "Slow moving traffic due to rush hour. Consider alternative routes.",
      severity: "medium",
      area: delhiArea,
      active: true,
    });

    // Chandigarh rush hour alerts
    const chandigarhArea = this.chandigarhAreas[Math.floor(Math.random() * this.chandigarhAreas.length)];
    await storage.createAlert({
      city: "Chandigarh",
      category: "traffic",
      title: `Congestion at ${chandigarhArea}`,
      message: "Moderate traffic due to peak hours. Expect slight delays.",
      severity: "low",
      area: chandigarhArea,
      active: true,
    });
  }

  async deactivateOldTrafficAlerts() {
    // Deactivate traffic alerts older than 2 hours
    try {
      await storage.deactivateOldAlerts("traffic", 2);
      console.log("Deactivated old traffic alerts");
    } catch (error) {
      console.error("Error deactivating traffic alerts:", error);
    }
  }
}

export const trafficService = new TrafficService();
