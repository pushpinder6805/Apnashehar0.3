import { newsService } from "./news-service";
import { weatherService } from "./weather-service";
import { fuelService } from "./fuel-service";
import { trafficService } from "./traffic-service";

export class DataScheduler {
  private intervals: NodeJS.Timeout[] = [];

  start() {
    console.log("Starting data scheduler...");

    // Initial fetch on startup
    this.fetchAllData();

    // News updates every 30 minutes (or env variable)
    const newsInterval = parseInt(process.env.NEWS_UPDATE_INTERVAL || "30") * 60 * 1000;
    this.intervals.push(
      setInterval(() => {
        newsService.fetchAndStoreNews();
        newsService.cleanupOldNews();
      }, newsInterval)
    );

    // Weather updates every 15 minutes
    const weatherInterval = parseInt(process.env.WEATHER_UPDATE_INTERVAL || "15") * 60 * 1000;
    this.intervals.push(
      setInterval(() => {
        weatherService.fetchAndStoreWeatherAlerts();
      }, weatherInterval)
    );

    // Fuel prices update once daily (1440 minutes)
    const fuelInterval = parseInt(process.env.FUEL_UPDATE_INTERVAL || "1440") * 60 * 1000;
    this.intervals.push(
      setInterval(() => {
        fuelService.fetchAndStoreFuelPrices();
        fuelService.cleanupOldPrices();
      }, fuelInterval)
    );

    // Traffic alerts every 10 minutes
    this.intervals.push(
      setInterval(() => {
        trafficService.checkAndCreateTrafficAlerts();
        trafficService.deactivateOldTrafficAlerts();
      }, 10 * 60 * 1000)
    );

    // Alert cleanup every hour
    const alertsInterval = parseInt(process.env.ALERTS_CLEANUP_INTERVAL || "60") * 60 * 1000;
    this.intervals.push(
      setInterval(() => {
        this.cleanupAlerts();
      }, alertsInterval)
    );

    console.log("Data scheduler started successfully");
  }

  stop() {
    this.intervals.forEach(interval => clearInterval(interval));
    this.intervals = [];
    console.log("Data scheduler stopped");
  }

  private async fetchAllData() {
    console.log("Performing initial data fetch...");

    try {
      await Promise.all([
        newsService.fetchAndStoreNews(),
        weatherService.fetchAndStoreWeatherAlerts(),
        fuelService.fetchAndStoreFuelPrices(),
        trafficService.checkAndCreateTrafficAlerts(),
      ]);
      console.log("Initial data fetch completed");
    } catch (error) {
      console.error("Error during initial data fetch:", error);
    }
  }

  private async cleanupAlerts() {
    // Deactivate alerts older than 24 hours
    try {
      await trafficService.deactivateOldTrafficAlerts();
      console.log("Alert cleanup completed");
    } catch (error) {
      console.error("Error during alert cleanup:", error);
    }
  }
}

export const dataScheduler = new DataScheduler();
