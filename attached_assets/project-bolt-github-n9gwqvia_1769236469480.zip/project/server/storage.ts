import {
  fuelPrices, alerts, news, offers,
  type FuelPrice, type InsertFuelPrice,
  type Alert, type InsertAlert,
  type NewsItem, type InsertNewsItem,
  type Offer, type InsertOffer
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, lt, sql } from "drizzle-orm";

export interface IStorage {
  // Fuel
  getFuelPrices(city?: string): Promise<FuelPrice[]>;
  createFuelPrice(price: InsertFuelPrice): Promise<FuelPrice>;
  deleteOldFuelPrices(days: number): Promise<void>;

  // Alerts
  getAlerts(city?: string, category?: string, active?: boolean): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  deactivateOldAlerts(category: string, hours: number): Promise<void>;

  // News
  getNews(city?: string): Promise<NewsItem[]>;
  createNews(news: InsertNewsItem): Promise<NewsItem>;
  deleteOldNews(days: number): Promise<void>;

  // Offers
  getOffers(city?: string, category?: string): Promise<Offer[]>;
  createOffer(offer: InsertOffer): Promise<Offer>;

  // Seeding check
  isEmpty(): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getFuelPrices(city?: string): Promise<FuelPrice[]> {
    if (city) {
      return await db.select().from(fuelPrices).where(eq(fuelPrices.city, city)).orderBy(desc(fuelPrices.date));
    }
    return await db.select().from(fuelPrices).orderBy(desc(fuelPrices.date));
  }

  async createFuelPrice(price: InsertFuelPrice): Promise<FuelPrice> {
    const [created] = await db.insert(fuelPrices).values(price).returning();
    return created;
  }

  async deleteOldFuelPrices(days: number): Promise<void> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    await db.delete(fuelPrices).where(lt(fuelPrices.date, cutoffDate));
  }

  async getAlerts(city?: string, category?: string, active?: boolean): Promise<Alert[]> {
    const conditions = [];
    if (city) conditions.push(eq(alerts.city, city));
    if (category) conditions.push(eq(alerts.category, category));
    if (active !== undefined) conditions.push(eq(alerts.active, active));
    
    if (conditions.length === 0) {
      return await db.select().from(alerts).orderBy(desc(alerts.createdAt));
    }
    
    return await db.select().from(alerts).where(and(...conditions)).orderBy(desc(alerts.createdAt));
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [created] = await db.insert(alerts).values(alert).returning();
    return created;
  }

  async deactivateOldAlerts(category: string, hours: number): Promise<void> {
    const cutoffDate = new Date();
    cutoffDate.setHours(cutoffDate.getHours() - hours);
    await db
      .update(alerts)
      .set({ active: false })
      .where(
        and(
          eq(alerts.category, category),
          lt(alerts.createdAt, cutoffDate),
          eq(alerts.active, true)
        )
      );
  }

  async getNews(city?: string): Promise<NewsItem[]> {
    if (city) {
      return await db.select().from(news).where(eq(news.city, city)).orderBy(desc(news.publishedAt));
    }
    return await db.select().from(news).orderBy(desc(news.publishedAt));
  }

  async createNews(item: InsertNewsItem): Promise<NewsItem> {
    const [created] = await db.insert(news).values(item).returning();
    return created;
  }

  async deleteOldNews(days: number): Promise<void> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    await db.delete(news).where(lt(news.publishedAt, cutoffDate));
  }

  async getOffers(city?: string, category?: string): Promise<Offer[]> {
    const conditions = [];
    if (city) conditions.push(eq(offers.city, city));
    if (category) conditions.push(eq(offers.category, category));
    
    if (conditions.length === 0) {
      return await db.select().from(offers);
    }
    
    return await db.select().from(offers).where(and(...conditions));
  }

  async createOffer(offer: InsertOffer): Promise<Offer> {
    const [created] = await db.insert(offers).values(offer).returning();
    return created;
  }

  async isEmpty(): Promise<boolean> {
    const [price] = await db.select().from(fuelPrices).limit(1);
    return !price;
  }
}

export const storage = new DatabaseStorage();
