import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { dataScheduler } from "./services/scheduler";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // === Fuel Prices ===
  app.get(api.fuel.list.path, async (req, res) => {
    const city = req.query.city as string | undefined;
    const prices = await storage.getFuelPrices(city);
    res.json(prices);
  });

  // === Alerts ===
  app.get(api.alerts.list.path, async (req, res) => {
    const city = req.query.city as string | undefined;
    const category = req.query.category as string | undefined;
    const active = req.query.active === 'true' ? true : req.query.active === 'false' ? false : undefined;

    const alerts = await storage.getAlerts(city, category, active);
    res.json(alerts);
  });

  app.post(api.alerts.create.path, async (req, res) => {
    try {
      const input = api.alerts.create.input.parse(req.body);
      const alert = await storage.createAlert(input);
      res.status(201).json(alert);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // === News ===
  app.get(api.news.list.path, async (req, res) => {
    const city = req.query.city as string | undefined;
    const items = await storage.getNews(city);
    res.json(items);
  });

  // === Offers ===
  app.get(api.offers.list.path, async (req, res) => {
    const city = req.query.city as string | undefined;
    const category = req.query.category as string | undefined;
    const offers = await storage.getOffers(city, category);
    res.json(offers);
  });

  // === Cities ===
  app.get(api.cities.list.path, (_req, res) => {
    res.json(['Chandigarh', 'Delhi']);
  });

  // === Start Data Scheduler ===
  // This will fetch real-time data from public APIs
  dataScheduler.start();

  console.log("Real-time data fetching is active. Data will update automatically.");

  return httpServer;
}
