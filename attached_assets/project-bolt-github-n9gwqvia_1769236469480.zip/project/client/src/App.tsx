import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CityProvider } from "@/lib/city-context";
import { Navigation } from "@/components/Navigation";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import NewsPage from "@/pages/News";
import OffersPage from "@/pages/Offers";
import AlertsPage from "@/pages/Alerts";

function Router() {
  return (
    <div className="min-h-screen bg-background font-sans selection:bg-primary/20">
      <Navigation />
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/news" component={NewsPage} />
        <Route path="/offers" component={OffersPage} />
        <Route path="/alerts" component={AlertsPage} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <CityProvider>
            <Router />
            <Toaster />
          </CityProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
