// API configuration for mobile and web
export const API_BASE_URL = import.meta.env.VITE_API_URL || '';

// Helper to build full API URLs
export function getApiUrl(path: string): string {
  if (path.startsWith('http')) {
    return path;
  }

  // Remove leading slash if present
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;

  // If API_BASE_URL is set, use it (mobile)
  if (API_BASE_URL) {
    return `${API_BASE_URL}/${cleanPath}`;
  }

  // Otherwise use relative path (web)
  return `/${cleanPath}`;
}
