import { useCity } from "@/lib/city-context";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MapPin, ChevronDown } from "lucide-react";
import { useCities } from "@/hooks/use-city-data";

export function CitySelector() {
  const { city, setCity } = useCity();
  const { data: cities } = useCities();

  // Fallback if API hasn't loaded
  const cityList = cities || ['Chandigarh', 'Delhi'];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          className="h-10 px-4 rounded-xl border-2 hover:bg-muted/50 transition-all duration-200 gap-2 font-display font-semibold"
        >
          <MapPin className="w-4 h-4 text-primary" />
          {city}
          <ChevronDown className="w-4 h-4 text-muted-foreground opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48 p-2 rounded-xl">
        {cityList.map((c) => (
          <DropdownMenuItem 
            key={c}
            onClick={() => setCity(c as any)}
            className={`
              rounded-lg cursor-pointer py-2.5 px-3 font-medium transition-colors
              ${city === c ? 'bg-primary/10 text-primary' : 'hover:bg-muted'}
            `}
          >
            {c}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
