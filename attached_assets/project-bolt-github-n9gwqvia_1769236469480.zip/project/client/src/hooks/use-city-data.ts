import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertAlert } from "@shared/routes";
import { getApiUrl } from "@/lib/api-config";

// === FUEL PRICES ===
export function useFuelPrices(city?: string) {
  return useQuery({
    queryKey: [api.fuel.list.path, city],
    queryFn: async () => {
      const path = city
        ? `${api.fuel.list.path}?city=${city}`
        : api.fuel.list.path;
      const url = getApiUrl(path);

      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch fuel prices");
      return api.fuel.list.responses[200].parse(await res.json());
    },
    enabled: !!city
  });
}

// === ALERTS ===
export function useAlerts(city?: string, category?: string) {
  return useQuery({
    queryKey: [api.alerts.list.path, city, category],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (city) params.append("city", city);
      if (category) params.append("category", category);

      const path = `${api.alerts.list.path}?${params.toString()}`;
      const url = getApiUrl(path);
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch alerts");
      return api.alerts.list.responses[200].parse(await res.json());
    },
    enabled: !!city
  });
}

export function useCreateAlert() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertAlert) => {
      const url = getApiUrl(api.alerts.create.path);
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create alert");
      return api.alerts.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.alerts.list.path] });
    },
  });
}

// === NEWS ===
export function useNews(city?: string) {
  return useQuery({
    queryKey: [api.news.list.path, city],
    queryFn: async () => {
      const path = city
        ? `${api.news.list.path}?city=${city}`
        : api.news.list.path;
      const url = getApiUrl(path);

      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch news");
      return api.news.list.responses[200].parse(await res.json());
    },
    enabled: !!city
  });
}

// === OFFERS ===
export function useOffers(city?: string, category?: string) {
  return useQuery({
    queryKey: [api.offers.list.path, city, category],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (city) params.append("city", city);
      if (category) params.append("category", category);

      const path = `${api.offers.list.path}?${params.toString()}`;
      const url = getApiUrl(path);
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch offers");
      return api.offers.list.responses[200].parse(await res.json());
    },
    enabled: !!city
  });
}

// === CITIES ===
export function useCities() {
  return useQuery({
    queryKey: [api.cities.list.path],
    queryFn: async () => {
      const url = getApiUrl(api.cities.list.path);
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch cities");
      return api.cities.list.responses[200].parse(await res.json());
    },
  });
}
