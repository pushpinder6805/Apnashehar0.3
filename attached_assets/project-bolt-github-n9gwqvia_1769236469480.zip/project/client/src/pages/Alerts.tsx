import { useCity } from "@/lib/city-context";
import { useAlerts } from "@/hooks/use-city-data";
import { CreateAlertDialog } from "@/components/CreateAlertDialog";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, AlertTriangle, Zap, CloudSun, CheckCircle2, MapPin } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function AlertsPage() {
  const { city } = useCity();
  const { data: alerts, isLoading } = useAlerts(city);

  const getIcon = (cat: string) => {
    switch(cat) {
      case 'traffic': return <AlertTriangle className="w-5 h-5" />;
      case 'power': return <Zap className="w-5 h-5" />;
      case 'weather': return <CloudSun className="w-5 h-5" />;
      default: return <AlertTriangle className="w-5 h-5" />;
    }
  };

  const getColorClass = (severity: string) => {
    switch(severity) {
      case 'critical': return 'bg-red-500 text-white border-red-600';
      case 'high': return 'bg-orange-500 text-white border-orange-600';
      case 'medium': return 'bg-yellow-500 text-white border-yellow-600';
      default: return 'bg-blue-500 text-white border-blue-600';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-4">
          <Link href="/">
            <button className="p-2 hover:bg-muted rounded-full transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Alerts & Incidents</h1>
            <p className="text-muted-foreground">Real-time community updates in {city}</p>
          </div>
        </div>
        <CreateAlertDialog />
      </div>

      <div className="space-y-4">
        {isLoading ? (
          [1, 2, 3].map((i) => <Skeleton key={i} className="h-32 rounded-2xl" />)
        ) : (
          alerts?.map((alert, index) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`
                relative p-6 rounded-2xl border-2 transition-all hover:shadow-lg bg-card
                ${!alert.active ? 'opacity-60 grayscale' : ''}
              `}
            >
              {!alert.active && (
                <div className="absolute top-4 right-4 z-10 bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> RESOLVED
                </div>
              )}

              <div className="flex gap-4">
                <div className={`
                  flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center
                  ${alert.category === 'traffic' ? 'bg-red-100 text-red-600' : ''}
                  ${alert.category === 'power' ? 'bg-amber-100 text-amber-600' : ''}
                  ${alert.category === 'weather' ? 'bg-blue-100 text-blue-600' : ''}
                `}>
                  {getIcon(alert.category)}
                </div>

                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <Badge className={`${getColorClass(alert.severity)} capitalize`}>
                      {alert.severity}
                    </Badge>
                    <span className="text-sm font-medium text-muted-foreground capitalize">
                      {alert.category}
                    </span>
                    <span className="text-xs text-muted-foreground ml-auto">
                      {alert.createdAt && formatDistanceToNow(new Date(alert.createdAt), { addSuffix: true })}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold mb-1">{alert.title}</h3>
                  <p className="text-muted-foreground">{alert.message}</p>
                  
                  <div className="flex items-center gap-2 mt-4 text-sm font-medium text-foreground/80 bg-muted/50 w-fit px-3 py-1.5 rounded-lg">
                    <MapPin className="w-4 h-4" />
                    {alert.area}
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        )}
        
        {alerts?.length === 0 && (
          <div className="text-center py-20 bg-muted/20 rounded-3xl border-2 border-dashed">
            <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold">All Clear!</h3>
            <p className="text-muted-foreground">No active incidents reported in {city} right now.</p>
          </div>
        )}
      </div>
    </div>
  );
}
