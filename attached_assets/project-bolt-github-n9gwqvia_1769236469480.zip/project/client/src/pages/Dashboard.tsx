import { useCity } from "@/lib/city-context";
import { useFuelPrices, useAlerts, useNews, useOffers } from "@/hooks/use-city-data";
import { CreateAlertDialog } from "@/components/CreateAlertDialog";
import { motion } from "framer-motion";
import { Fuel, ArrowRight, Zap, AlertTriangle, CloudSun, Clock, MapPin } from "lucide-react";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { city } = useCity();
  const { data: fuel, isLoading: loadingFuel } = useFuelPrices(city);
  const { data: alerts, isLoading: loadingAlerts } = useAlerts(city);
  const { data: news, isLoading: loadingNews } = useNews(city);
  const { data: offers, isLoading: loadingOffers } = useOffers(city);

  const activeAlerts = alerts?.filter(a => a.active) || [];
  const highPriorityAlerts = activeAlerts.filter(a => ['high', 'critical'].includes(a.severity));

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header Section */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground">
            Good Morning, {city}
          </h1>
          <div className="flex items-center gap-2 mt-2 text-muted-foreground">
            <CloudSun className="w-5 h-5" />
            <span>28°C Mostly Sunny</span>
            <span className="w-1 h-1 bg-muted-foreground/30 rounded-full" />
            <span>{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
          </div>
        </div>
        
        <CreateAlertDialog />
      </motion.div>

      {/* Main Grid */}
      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-12 gap-6"
      >
        {/* Fuel Prices Widget - Spans 4 cols */}
        <motion.div variants={item} className="md:col-span-4 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Today's Fuel</h2>
            <Link href="/news" className="text-sm text-primary hover:underline">Full report</Link>
          </div>
          
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-32 bg-primary/10 rounded-full blur-3xl" />
            
            {loadingFuel ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full bg-white/10" />
                <Skeleton className="h-10 w-full bg-white/10" />
                <Skeleton className="h-10 w-full bg-white/10" />
              </div>
            ) : (
              <div className="space-y-4 relative z-10">
                {fuel?.map((f) => (
                  <div key={f.id} className="flex items-center justify-between p-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/5 hover:bg-white/15 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400">
                        <Fuel className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-medium">{f.type}</p>
                        <p className="text-xs text-slate-400">Per Litre</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold font-display">₹{f.price}</p>
                      <p className="text-xs text-green-400 flex items-center justify-end gap-1">
                        -0.5% <ArrowRight className="w-3 h-3 rotate-45" />
                      </p>
                    </div>
                  </div>
                ))}
                {!fuel?.length && <p className="text-slate-400 text-center py-4">No data available</p>}
              </div>
            )}
          </div>
        </motion.div>

        {/* Alerts Widget - Spans 8 cols */}
        <motion.div variants={item} className="md:col-span-8 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
              </span>
              Live Alerts
            </h2>
            <Link href="/alerts" className="text-sm text-primary hover:underline">View all</Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {loadingAlerts ? (
              [1, 2].map(i => <Skeleton key={i} className="h-32 rounded-2xl" />)
            ) : (
              activeAlerts.slice(0, 4).map((alert) => (
                <div 
                  key={alert.id}
                  className={`
                    p-5 rounded-2xl border flex flex-col justify-between h-full transition-all hover:shadow-md
                    ${alert.category === 'traffic' ? 'bg-red-50/50 border-red-100 dark:bg-red-950/10 dark:border-red-900/50' : ''}
                    ${alert.category === 'power' ? 'bg-amber-50/50 border-amber-100 dark:bg-amber-950/10 dark:border-amber-900/50' : ''}
                    ${alert.category === 'weather' ? 'bg-blue-50/50 border-blue-100 dark:bg-blue-950/10 dark:border-blue-900/50' : ''}
                  `}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className={`
                      p-2 rounded-lg
                      ${alert.category === 'traffic' ? 'bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-400' : ''}
                      ${alert.category === 'power' ? 'bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-400' : ''}
                      ${alert.category === 'weather' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-400' : ''}
                    `}>
                      {alert.category === 'traffic' && <AlertTriangle className="w-5 h-5" />}
                      {alert.category === 'power' && <Zap className="w-5 h-5" />}
                      {alert.category === 'weather' && <CloudSun className="w-5 h-5" />}
                    </div>
                    <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground px-2 py-1 bg-background/50 rounded-md">
                      {alert.severity}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg leading-tight mb-1">{alert.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">{alert.message}</p>
                    <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                      <MapPin className="w-3 h-3" /> {alert.area}
                      <span className="w-1 h-1 bg-muted-foreground/30 rounded-full" />
                      {alert.createdAt && formatDistanceToNow(new Date(alert.createdAt), { addSuffix: true })}
                    </div>
                  </div>
                </div>
              ))
            )}
            {!activeAlerts.length && (
              <div className="col-span-full py-12 text-center text-muted-foreground border-2 border-dashed rounded-2xl bg-muted/20">
                <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-3">
                  <Clock className="w-6 h-6 opacity-50" />
                </div>
                <p>No active alerts right now. Drive safe!</p>
              </div>
            )}
          </div>
        </motion.div>

        {/* News Feed - Spans full width */}
        <motion.div variants={item} className="col-span-full md:col-span-8 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Top News in {city}</h2>
            <Link href="/news" className="text-sm text-primary hover:underline">Read all</Link>
          </div>

          <div className="space-y-4">
            {loadingNews ? (
               [1, 2, 3].map(i => <Skeleton key={i} className="h-24 w-full rounded-2xl" />)
            ) : (
              news?.slice(0, 3).map((item) => (
                <div key={item.id} className="group flex gap-4 p-4 rounded-2xl bg-card border hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/5 cursor-pointer">
                  {item.imageUrl && (
                    <div className="w-24 h-24 sm:w-32 sm:h-24 flex-shrink-0 rounded-xl overflow-hidden">
                      <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                  )}
                  <div className="flex flex-col justify-between py-1">
                    <div>
                      <h3 className="font-bold text-lg group-hover:text-primary transition-colors line-clamp-2">{item.title}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-1 hidden sm:block">{item.summary}</p>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-2">
                      <span className="font-semibold text-primary">{item.source}</span>
                      <span className="w-1 h-1 bg-muted-foreground/30 rounded-full" />
                      {item.publishedAt && formatDistanceToNow(new Date(item.publishedAt), { addSuffix: true })}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>
        
        {/* Offers Widget - Spans 4 cols */}
        <motion.div variants={item} className="col-span-full md:col-span-4 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Local Offers</h2>
            <Link href="/offers" className="text-sm text-primary hover:underline">View all</Link>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {loadingOffers ? (
              [1, 2].map(i => <Skeleton key={i} className="h-40 rounded-2xl" />)
            ) : (
              offers?.slice(0, 2).map((offer) => (
                <div key={offer.id} className="relative p-5 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white overflow-hidden shadow-lg">
                  <div className="relative z-10">
                    <span className="px-2 py-1 bg-white/20 rounded-md text-xs font-medium backdrop-blur-md border border-white/20">
                      {offer.category}
                    </span>
                    <h3 className="font-bold text-xl mt-3">{offer.title}</h3>
                    <p className="text-white/80 text-sm mt-1 mb-4">{offer.businessName}</p>
                    
                    {offer.code && (
                      <div className="flex items-center gap-2 bg-black/20 p-2 rounded-lg border border-white/10 border-dashed">
                        <span className="text-xs uppercase tracking-wider text-white/60">Code:</span>
                        <span className="font-mono font-bold tracking-widest">{offer.code}</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Decorative circles */}
                  <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-white/10 rounded-full blur-2xl" />
                  <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-32 h-32 bg-purple-900/20 rounded-full blur-xl" />
                </div>
              ))
            )}
          </div>
        </motion.div>

      </motion.div>
    </div>
  );
}
