import { useCity } from "@/lib/city-context";
import { useOffers } from "@/hooks/use-city-data";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, ShoppingBag, Clock, Tag } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";

export default function OffersPage() {
  const { city } = useCity();
  const { data: offers, isLoading } = useOffers(city);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8 flex items-center gap-4">
        <Link href="/">
          <button className="p-2 hover:bg-muted rounded-full transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold">Local Deals</h1>
          <p className="text-muted-foreground">Best offers near you in {city}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          [1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-64 rounded-2xl" />
          ))
        ) : (
          offers?.map((offer, index) => (
            <motion.div
              key={offer.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              className="bg-card rounded-2xl border shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden group flex flex-col"
            >
              <div className="h-32 bg-gradient-to-r from-primary/10 to-accent/10 flex items-center justify-center relative overflow-hidden">
                <ShoppingBag className="w-12 h-12 text-primary/20 group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute top-4 right-4 bg-white/90 dark:bg-black/50 backdrop-blur text-foreground px-3 py-1 rounded-full text-xs font-bold shadow-sm border">
                  {offer.category}
                </div>
              </div>
              
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center gap-2 text-sm text-primary font-semibold mb-2">
                  <Tag className="w-4 h-4" />
                  {offer.businessName}
                </div>
                
                <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                  {offer.title}
                </h3>
                
                <p className="text-muted-foreground text-sm mb-6 flex-grow">
                  {offer.description}
                </p>

                <div className="space-y-4 pt-4 border-t border-dashed border-border">
                  {offer.code ? (
                    <div className="bg-muted/50 p-3 rounded-xl border border-dashed border-primary/30 flex items-center justify-between group-hover:border-primary/60 transition-colors">
                      <span className="text-xs text-muted-foreground uppercase tracking-wide">Coupon Code</span>
                      <span className="font-mono font-bold text-lg text-primary">{offer.code}</span>
                    </div>
                  ) : (
                    <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-xl border border-green-200 dark:border-green-800 text-center text-green-700 dark:text-green-400 font-semibold">
                      No Code Required
                    </div>
                  )}

                  {offer.expiresAt && (
                    <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      Expires {format(new Date(offer.expiresAt), 'PPP')}
                    </div>
                  )}
                  
                  <Button className="w-full rounded-xl">Claim Offer</Button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
