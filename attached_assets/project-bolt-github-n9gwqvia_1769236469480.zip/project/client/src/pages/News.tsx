import { useCity } from "@/lib/city-context";
import { useNews } from "@/hooks/use-city-data";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { ArrowLeft, Share2, Bookmark } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function NewsPage() {
  const { city } = useCity();
  const { data: news, isLoading } = useNews(city);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8 flex items-center gap-4">
        <Link href="/">
          <button className="p-2 hover:bg-muted rounded-full transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
        </Link>
        <h1 className="text-3xl font-bold">Latest News in {city}</h1>
      </div>

      <div className="space-y-6">
        {isLoading ? (
          [1, 2, 3, 4].map((i) => (
            <div key={i} className="flex flex-col md:flex-row gap-6">
              <Skeleton className="w-full md:w-48 h-48 md:h-32 rounded-xl" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </div>
            </div>
          ))
        ) : (
          news?.map((item, index) => (
            <motion.article 
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="group bg-card rounded-2xl overflow-hidden border hover:shadow-lg transition-all duration-300"
            >
              <div className="flex flex-col md:flex-row">
                {item.imageUrl && (
                  <div className="w-full md:w-64 h-48 md:h-auto flex-shrink-0 relative overflow-hidden">
                    <img 
                      src={item.imageUrl} 
                      alt={item.title} 
                      className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                    />
                  </div>
                )}
                <div className="p-6 flex-1 flex flex-col">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-primary px-2 py-1 bg-primary/10 rounded-md">
                      {item.source}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {item.publishedAt && formatDistanceToNow(new Date(item.publishedAt), { addSuffix: true })}
                    </span>
                  </div>
                  
                  <h2 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors">
                    {item.title}
                  </h2>
                  
                  <p className="text-muted-foreground mb-4 flex-grow">
                    {item.summary}
                  </p>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-border/50">
                    <div className="flex gap-2">
                      <button className="p-2 hover:bg-muted rounded-full text-muted-foreground hover:text-foreground transition-colors">
                        <Share2 className="w-4 h-4" />
                      </button>
                      <button className="p-2 hover:bg-muted rounded-full text-muted-foreground hover:text-foreground transition-colors">
                        <Bookmark className="w-4 h-4" />
                      </button>
                    </div>
                    {item.url && (
                      <a 
                        href={item.url} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-sm font-semibold text-primary hover:underline"
                      >
                        Read Full Story
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </motion.article>
          ))
        )}
      </div>
    </div>
  );
}
