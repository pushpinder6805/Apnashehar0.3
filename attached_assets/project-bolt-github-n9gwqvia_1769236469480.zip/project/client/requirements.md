## Packages
framer-motion | Complex animations for page transitions and widgets
date-fns | Formatting dates for news and alerts
clsx | Conditional class names utility
tailwind-merge | Merging tailwind classes safely

## Notes
API endpoints are defined in shared/routes.ts
Using Unsplash for demo images
City selection state will be managed via React Context
