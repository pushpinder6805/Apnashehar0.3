#!/usr/bin/env node

// iOS Setup Checker - Run this to diagnose issues
import { existsSync, readFileSync } from 'fs';
import { execSync } from 'child_process';
import { join } from 'path';

console.log('🔍 Checking iOS Setup...\n');

const checks = [];
let allPassed = true;

// Check 1: Node modules installed
const check1 = existsSync('./node_modules/@capacitor/core');
checks.push({
  name: 'Capacitor installed',
  passed: check1,
  fix: 'Run: npm install'
});
if (!check1) allPassed = false;

// Check 2: .env file exists
const check2 = existsSync('./.env');
checks.push({
  name: '.env file exists',
  passed: check2,
  fix: 'Create .env file with VITE_API_URL'
});
if (!check2) allPassed = false;

// Check 3: .env has API URL
let check3 = false;
if (check2) {
  const envContent = readFileSync('./.env', 'utf-8');
  check3 = envContent.includes('VITE_API_URL');
}
checks.push({
  name: 'VITE_API_URL configured',
  passed: check3,
  fix: 'Add VITE_API_URL=https://your-backend.com to .env'
});
if (!check3) allPassed = false;

// Check 4: Build exists
const check4 = existsSync('./dist/public');
checks.push({
  name: 'Build exists',
  passed: check4,
  fix: 'Run: npm run build'
});
if (!check4) allPassed = false;

// Check 5: iOS platform added
const check5 = existsSync('./ios');
checks.push({
  name: 'iOS platform added',
  passed: check5,
  fix: 'Run: npx cap add ios'
});
if (!check5) allPassed = false;

// Check 6: capacitor.config.ts exists
const check6 = existsSync('./capacitor.config.ts');
checks.push({
  name: 'Capacitor config exists',
  passed: check6,
  fix: 'Config file should have been created automatically'
});
if (!check6) allPassed = false;

// Check 7: Backend URL in capacitor config
let check7 = false;
if (check6) {
  const configContent = readFileSync('./capacitor.config.ts', 'utf-8');
  check7 = configContent.includes('server:') &&
           !configContent.includes('http://localhost:5000');
}
checks.push({
  name: 'Backend URL configured in Capacitor',
  passed: check7,
  fix: 'Update server.url in capacitor.config.ts'
});
if (!check7) allPassed = false;

// Display results
console.log('Results:\n');
checks.forEach(check => {
  const icon = check.passed ? '✅' : '❌';
  console.log(`${icon} ${check.name}`);
  if (!check.passed) {
    console.log(`   Fix: ${check.fix}\n`);
  }
});

console.log('\n' + '='.repeat(50));

if (allPassed) {
  console.log('✅ All checks passed! Ready to build for iOS.\n');
  console.log('Next steps:');
  console.log('1. Run: npm run build:mobile');
  console.log('2. Run: npm run ios');
  console.log('3. Build in Xcode\n');
} else {
  console.log('❌ Some checks failed. Fix the issues above.\n');
  console.log('After fixing, run this script again: node check-ios-setup.js\n');
}

// Test backend if URL is configured
if (check3) {
  const envContent = readFileSync('./.env', 'utf-8');
  const match = envContent.match(/VITE_API_URL=(.+)/);
  if (match) {
    const url = match[1].trim();
    console.log(`\n🌐 Testing backend at: ${url}`);
    try {
      const testUrl = `${url}/api/cities`;
      console.log(`   Checking: ${testUrl}`);
      const result = execSync(`curl -s -o /dev/null -w "%{http_code}" "${testUrl}"`, {
        encoding: 'utf-8'
      });
      if (result.trim() === '200') {
        console.log('   ✅ Backend is reachable!\n');
      } else {
        console.log(`   ⚠️  Backend returned status: ${result}`);
        console.log('   Make sure your backend server is running.\n');
      }
    } catch (error) {
      console.log('   ❌ Cannot reach backend');
      console.log('   Make sure:');
      console.log('   - Backend server is running');
      console.log('   - URL is correct');
      console.log('   - No firewall blocking access\n');
    }
  }
}
